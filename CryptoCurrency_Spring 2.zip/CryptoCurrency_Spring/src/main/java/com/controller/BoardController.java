package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dto.Board;
import com.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	BoardService service;
	
	public Board BoardCrawling() {
		return null;
	}
	
	@RequestMapping(value="/listBoard", method=RequestMethod.GET)
	@CrossOrigin	// cross domain 해결
	public @ResponseBody List<Board> listBoard() {
		return service.listBoard();
	}
	
	@RequestMapping(value="/addBoard", method=RequestMethod.POST)
	@CrossOrigin	// cross domain 해결
	public @ResponseBody void addBoard(@RequestBody Board board) {
		service.addBoard(board);
	}
	
	public void updateBoard(Board board) {
		
	}
	
	public void deleteBoard(int num) {
		
	}
	
	public void deleteBoard(String email) {
		
	}
}
