import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { Bithumb, Upbit, CurrencyTime } from '../../services/currency/currency';
import { CurrencyService } from '../../services/currency/currency.service';

@Component({
    selector: 'app-charts',
    templateUrl: './charts.component.html',
    styleUrls: ['./charts.component.scss'],
    animations: [routerTransition()]
})
export class ChartsComponent implements OnInit {

    // lineChart
    public lineChartData: Array<any> = [
        { data: [6500, 5900, 8000, 8100, 5600, 5500, 4000], label: 'Bithumb' },
        { data: [2800, 4800, 4000, 1900, 8600, 2700, 9000], label: 'Upbit' },
    ];
    public lineChartLabels: Array<any> = [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July'
    ];
    public lineChartOptions: any = {
        responsive: true
    };
    public lineChartColors: Array<any> = [
        {
            backgroundColor: 'rgba(255, 194, 207, 0.5)',
            borderColor: 'rgb(255, 99, 131)',
            pointBackgroundColor: 'rgb(103, 58, 183)',
            pointBorderColor: '#dc3545',
            pointHoverBackgroundColor: '#dc3545',
            pointHoverBorderColor: 'rgba(103, 58, 183, .8)'
        },
        {
            backgroundColor: 'rgba(255,235,190,0.5)',
            borderColor: 'rgba(254,207,89,1)',
            pointBackgroundColor: 'rgba(77,83,96,1)',
            pointBorderColor: '#ffc107',
            pointHoverBackgroundColor: '#ffc107',
            pointHoverBorderColor: 'rgba(77,83,96,1)'
        },
    ];
    public lineChartLegend: boolean = true;
    public lineChartType: string = 'line';

    bithumbArr:Bithumb[];
    upbitArr:Upbit[];
    
    constructor(private currencyService:CurrencyService) {}

    ngOnInit() {
        this.currencyService.chartsBithumb(new CurrencyTime('BTC', '20181016010000', '20181016080000', 30))
                            .subscribe(res => { 
                                console.log('subscribe', res);
                            }, error => { console.log(error)});
        this.currencyService.chartsUpbit(new CurrencyTime('KRW-BTC', '20181016010000', '20181016080000', 30))
                            .subscribe(res => { 
                                console.log('subscribe', res);
                            }, error => { console.log(error)});
    }
}
