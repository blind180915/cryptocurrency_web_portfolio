package com.controller;

import org.springframework.stereotype.Controller;

import com.dto.Board;

@Controller
public class BoardController {
	public Board BoardCrawling() {
		return null;
	}
	
	public void addBoard(Board board) {
		
	}
	
	public void updateBoard(Board board) {
		
	}
	
	public void deleteBoard(int num) {
		
	}
	
	public void deleteBoard(String email) {
		
	}
}
