package com.dto;

import org.apache.ibatis.type.Alias;

@Alias("CurrencyTime")
public class CurrencyTime {
	private String currency;
	private String startTime;
	private String endTime;
	private double interval;
	
	public CurrencyTime() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrencyTime(String currency, String startTime, String endTime, double interval) {
		super();
		this.currency = currency;
		this.startTime = startTime;
		this.endTime = endTime;
		this.interval = interval;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public double getInterval() {
		return interval;
	}

	public void setInterval(double interval) {
		this.interval = interval;
	}

	@Override
	public String toString() {
		return "CurrencyTime [currency=" + currency + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", interval=" + interval + "]";
	}
}
