package com.dto;

public class Board {

}
